## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Advanced  tasks have been implemented: editing, deleting and adding fields, calculating the average price and quantity of goods, calculating the total price and quantity of goods.
 To edit a line, click on it and it will appear in the edit form.

