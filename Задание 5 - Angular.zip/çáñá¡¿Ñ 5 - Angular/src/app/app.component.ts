import {AfterViewInit, Component} from '@angular/core';
import {DataService} from './data.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit{
  public data:  object[];
  private obj: object | undefined;
  public chosenRow: number = 0;
  private value: any;
  private el: any;

  constructor(private readonly dataService: DataService ) {
    this.data = this.dataService.getData();

  }

  ngAfterViewInit(){
  }

  public getColumnClass(key: string) : string{
    return key;
  }
  public countSum(property: string): number{
    let properties = document.querySelectorAll(`.${property}`);
    let sum = 0;
    // @ts-ignore
    for (let property of properties) {
      sum += Number(property.innerHTML);
    }

    return sum;
  }
  public  countAverageValue(property: string): number {
    let properties = document.querySelectorAll(`.${property}`)
    let averageValue = 0;
    // @ts-ignore
    for (let property of properties) {
      averageValue += Number(property.innerHTML);
    }
    averageValue = Math.round((averageValue / properties.length) * 100) / 100;
    return averageValue;
  }

  public chooseRow(row: number):void{
    let obj = this.data[row];
    for (let  [key, value] of Object.entries(this.data[row])) {
      // @ts-ignore
      document.querySelector(`#Input-${key}`).value = value;
    }
   this.chosenRow = row;
  }

  public addRow(): void {
    let obj = {};
    for (let key of Object.keys(this.data[0])) {
      // @ts-ignore
      obj[`${key}`] = document.querySelector(`#Input-${key}`).value;
    }
    this.data.push(obj);
  }
  private getRowCount(): number {
    // @ts-ignore
    const {innerHTML} = document.querySelector('.rowNumber');
    return Number(innerHTML);
  }

   public deleteRow(): void {
    let count = this.getRowCount();
    this.data.splice(count, 1);
  }
  public editRow():void {
    let count = this.getRowCount();
    let obj = this.data[count];
    for (let key of Object.keys(this.data[count])) {
      // @ts-ignore
      obj[`${key}`] = document.querySelector(`#Input-${key}`).value;
    }
    this.data[count] = obj;
  }

}
