## Available Scripts

In the project directory, you can run:

### `npm start`

## Tasks have been implemented: rendering the table with initial data, fetch queries, calculating the average price and quantity of goods, calculating the total price and quantity of goods
