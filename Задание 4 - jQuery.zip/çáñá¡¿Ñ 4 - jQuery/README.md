## Available Scripts

In the project directory, you can run:
### `npm i`, then `gulp`

Created using jQuery library.
After rendering Gulp will create a folder with compiled plane JS,CSS and HTML code.


## Advanced  tasks have been implemented: editing, deleting and adding fields, calculating the average price and quantity of goods, calculating the total price and quantity of goods.
 To edit a line, click on it and it will appear in the edit form.
